import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

// Create a Form widget.
class MyCustomForm extends StatefulWidget {
  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

// Create a corresponding State class.
// This class holds data related to the form.
class MyCustomFormState extends State<MyCustomForm> {
  String itinearyTitle;
  String tagplaces;
  String itineary;
  Firestore _firestore = Firestore.instance;

  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a GlobalKey<FormState>,
  // not a GlobalKey<MyCustomFormState>.
  final _formKey = GlobalKey<FormState>();

  var splitList = [];

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              onChanged: (input) {
                itinearyTitle = input;
              },
              decoration: InputDecoration(labelText: 'Title itineary:'),
            ),
            TextField(
              onChanged: (value) {
                tagplaces = value;
              },
              decoration: InputDecoration(labelText: 'TagPlaces:'),
            ),
            TextField(
              onChanged: (val) {
                itineary = val;
              },
              decoration: InputDecoration(labelText: 'iternary:'),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: RaisedButton(
                    onPressed: () {
                      print(itinearyTitle);
                      print(itineary);
                      print(tagplaces);
                      if (itinearyTitle.length > 0 &&
                          itineary.length > 0 &&
                          tagplaces.length > 0) {
                        var docref =
                            _firestore.collection('clients').document();
                        docref.setData({
                          'itinearyId': docref.documentID,
                          'itinearyTitle': itinearyTitle,
                          'body': itineary,
                          'places': tagplaces,
                          'places_divided': tagplaces.split(" "),
                          'placeKey': tagplaces[0],
                        });
                      }
                    },
                    child: Text('Submit'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
